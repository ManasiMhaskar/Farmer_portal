/* assets/js/script.js - FIXED VERSION */

document.addEventListener('DOMContentLoaded', () => {
  // Set current year
  const y = new Date().getFullYear();
  const yearElement = document.getElementById('year');
  if (yearElement) yearElement.textContent = y;

  // Activate current nav link
  const links = document.querySelectorAll('.navbar .nav-link');
  links.forEach(a => {
    if (a.getAttribute('href') === location.pathname.split('/').pop() || 
        (location.pathname.endsWith('/') && a.getAttribute('href') === 'index.html')) {
      a.classList.add('active');
    }
  });

  // REVEAL FIX: Show all content immediately
  const reveals = document.querySelectorAll('.reveal');
  reveals.forEach(el => {
    el.style.opacity = '1';
    el.style.transform = 'translateY(0)';
    el.classList.add('active', 'visible', 'show');
  });

  // Load contact form data if exists
  loadContact();
});

/* Weather function */
async function fetchWeather(query) {
  const apiKey = 'YOUR_API_KEY'; // <-- REPLACE WITH YOUR KEY
  const base = 'https://api.openweathermap.org/data/2.5/forecast';
  
  try {
    const url = `${base}?q=${encodeURIComponent(query)}&units=metric&appid=${apiKey}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('City not found');
    const data = await res.json();

    // today's summary (take first entry)
    const today = data.list[0];
    const city = data.city.name + ', ' + data.city.country;

    // build 3-day simple forecast
    const forecast = [];
    for (let i=0; i<3; i++){
      const idx = i*8;
      if (data.list[idx]) {
        const item = data.list[idx];
        forecast.push({
          date: item.dt_txt.split(' ')[0],
          temp: item.main.temp,
          humidity: item.main.humidity,
          rain: item.pop !== undefined ? Math.round(item.pop*100) : 0,
          desc: item.weather[0].description
        });
      }
    }
    
    return {
      city, 
      today: {
        temp: today.main.temp, 
        humidity: today.main.humidity, 
        rain: Math.round(today.pop*100 || 0), 
        desc: today.weather[0].description
      }, 
      forecast
    };
  } catch (err) {
    console.error(err);
    throw err;
  }
}

/* Soil recommendations */
const soilRecommendations = {
  'sandy': 'Use organic compost, apply NPK (10-20-10). Avoid overwatering; improve water holding with mulch.',
  'clay': 'Use gypsum for structure, apply balanced NPK (12-12-17). Improve drainage and organic matter.',
  'loam': 'Loam is ideal. Use minimal chemical fertilizers: starter N and K as per crop.',
  'silty': 'Improve aeration with organic matter and apply balanced fertilizers carefully.',
  'peaty': 'Add lime to reduce acidity and balanced NPK; avoid waterlogging.'
};

function getSoilRecommendation(type) {
  return soilRecommendations[type] || 'Please choose a soil type';
}

/* Schemes search filter */
function filterSchemes(query){
  const cards = document.querySelectorAll('.scheme-card');
  const q = query.trim().toLowerCase();
  cards.forEach(card => {
    const title = card.dataset.title.toLowerCase();
    const content = card.dataset.content?.toLowerCase() || '';
    if (title.includes(q) || content.includes(q)) {
      card.style.display = '';
    } else {
      card.style.display = 'none';
    }
  });
}

/* Calculators */
function calculateSeedRequirement(areaHa, rateKgPerHa){
  const result = Number(areaHa) * Number(rateKgPerHa);
  return Number.isFinite(result) ? result : null;
}

function calculateWaterUsage(areaHa, m3perHa){
  return Number(areaHa) * Number(m3perHa);
}

function calculateProfit(areaHa, yieldPerHa, pricePerUnit, totalCosts){
  const revenue = Number(areaHa) * Number(yieldPerHa) * Number(pricePerUnit);
  return revenue - Number(totalCosts);
}

/* Contact form localStorage */
function saveContactForm(data){
  const key = 'farmer_portal_contacts';
  const prev = JSON.parse(localStorage.getItem(key) || '[]');
  prev.push({...data, ts: new Date().toISOString()});
  localStorage.setItem(key, JSON.stringify(prev));
}

function loadContact(){
  const name = document.getElementById('name');
  const email = document.getElementById('email');
  const msg = document.getElementById('msg');
  
  if (!name || !email || !msg) return;
  
  // Load saved data if exists
  const saved = localStorage.getItem('contact_form');
  if (saved) {
    try {
      const data = JSON.parse(saved);
      name.value = data.name || '';
      email.value = data.email || '';
      msg.value = data.message || data.msg || '';
    } catch(e) {
      console.log('No saved contact data');
    }
  }
}

// Make functions available globally
window.FarmerPortal = {
  fetchWeather,
  getSoilRecommendation,
  filterSchemes,
  calculateSeedRequirement,
  calculateWaterUsage,
  calculateProfit,
  saveContactForm,
  loadContact
};

// Simple form submission for contact.html
if (window.location.pathname.includes('contact.html')) {
  document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    if (form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const msg = document.getElementById('msg').value;
        
        if (name && email && msg) {
          saveContactForm({ name, email, message: msg });
          alert('Message saved locally (demo mode)');
          form.reset();
        }
      });
    }
  });
}